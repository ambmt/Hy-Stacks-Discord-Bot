Notes:

* `"unified-signatures": false` because of https://github.com/Microsoft/dtslint/issues/183
