License information: https://github.com/omnent/omnent-licenses/blob/master/licenses/OMv2-FO.txt

Copyright 2017 Ethan Davis

Permission is hereby granted, for free, to any person obtaining a copy of this software and associated documentation files (collectively "the Software" or "THE SOFTWARE"), to (without restriction) use, modify, copy, publish, execute, distribute, sublicense, and sell the Software and to allow people who gain access to the Software to do the same as long as this entire license and the above copyright notice are included in all copies or portions of the Software.

NOTWITHSTANDING ANYTHING IN CONTRADICTION, THE AUTHORS AND COPYRIGHT HOLDERS OF THE SOFTWARE SHALL UNDER NO CIRCUMSTANCES BE HELD LIABLE FOR ANY DAMAGES, CLAIM, OR OTHER LIABILITY RELATED TO, IN CONNECTION WITH, OR CAUSED BY USE OR DISTRIBUTION OF THE SOFTWARE. THE SOFTWARE IS PROVIDED "AS-IS" AND IS NOT PROVIDED WITH WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, NONINFRINGEMENT, AND ANY WARRANTY ARISING OUR OF PRIOR COURSE OF DEALING AND USAGE OF TRADE.