const util = require('util')

const HypixelAPI = require('./')

const client = new HypixelAPI('367f3718-d302-475f-b54d-744162e85b78')

;(async function() {
	/*console.log(util.inspect(await client.getPlayer('name', 'ethanent'), {
		'depth': Infinity
	}))

	console.log(util.inspect(await client.findGuild('memberName', 'ethanent'), {
		'depth': Infinity
	}))

	console.log(util.inspect(await client.getGuild('52e572a684ae6e67043aa084'), {
		'depth': Infinity
	}))

	console.log(util.inspect(await client.getFriends('name', 'ethanent'), {
		'depth': Infinity
	}))

	console.log(util.inspect(await client.getBoosters(), {
		'depth': Infinity
	}))

	console.log(util.inspect(await client.getKey(), {
		'depth': Infinity
	}))

	console.log(util.inspect(await client.getLeaderboards(), {
		'depth': Infinity
	}))

	console.log(util.inspect(await client.getSession('name', 'ethanent'), {
		'depth': Infinity
	}))

	console.log(util.inspect(await client.getWatchdogStats(), {
		'depth': Infinity
	}))*/

	console.log(await client.getSkyblockAuctions(0))
})()